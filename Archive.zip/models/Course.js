const mongoose = require('mongoose');

const sectionSchema = new mongoose.Schema({
  sectionNumber: Number,
  title: String,
  characterIntro: String,
  description: String,
  gif: String,
  funFact: String,
  problem: String,
  code: String,
  challenge: String,
  hint: String,
  finalQuest: {
    description: String,
    code: String,
    hint: String
  }
});

const lessonSchema = new mongoose.Schema({
  lessonNumber: Number,
  lessonId: String,
  title: String,
  sections: [sectionSchema]
});

const courseSchema = new mongoose.Schema({
  id: String,
  title: String,
  description: String,
  lessons: [lessonSchema]
});

module.exports = mongoose.model('Course', courseSchema);