const mongoose = require('mongoose');

const progressSchema = new mongoose.Schema({
  courseId: String,
  numberOfSections: Number,
  completedSections: { type: Number, default: 0 },
  progressPercentage: { type: Number, default: 0 }
});

const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  password: String,
  totalPoints: { type: Number, default: 0 },
  enrolledCourses: [progressSchema]
});

module.exports = mongoose.model('User', userSchema);