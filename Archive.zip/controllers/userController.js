
const Course = require('../models/Course')
const User = require('../models/User')
exports.enrollCourse = async (req, res) => {
  const { userId, courseId } = req.body;

  try {
    const user = await User.findById(userId);
    const course = await Course.findOne({ id: courseId });

    // ⛔️ Check if course exists
    if (!course) {
      return res.status(404).json({ error: 'Course not found' });
    }

    // ✅ Calculate total sections
    const totalSections = course.lessons.reduce(
      (acc, lesson) => acc + lesson.sections.length,
      0
    );

    // ✅ Avoid re-enrolling
    const alreadyEnrolled = user.progress.enrolledCourses.find(
      (enrolled) => enrolled.courseID === courseId
    );
    if (alreadyEnrolled) {
      return res.status(400).json({ error: 'Already enrolled in this course' });
    }

    // ✅ Add course progress
    user.progress.enrolledCourses.push({
      courseID: courseId,
      numberOfSections: totalSections,
      completedSections: 0,
      progressPercentage: 0
    });

    await user.save();

    res.status(200).json({ message: 'Enrolled successfully', user });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal server error' });
  }
};


exports.completeSection = async (req, res) => {
  const user = await User.findById(req.userId);
  const { courseId } = req.body;

  const courseProgress = user.enrolledCourses.find(c => c.courseId === courseId);
  if (!courseProgress) return res.status(404).json({ message: 'Not enrolled' });

  courseProgress.completedSections++;
  courseProgress.progressPercentage = Math.floor((courseProgress.completedSections / courseProgress.numberOfSections) * 100);

  user.totalPoints += 10;

  if (courseProgress.completedSections === courseProgress.numberOfSections) {
    user.totalPoints += 100;
  }

  await user.save();
  res.json({ message: 'Section completed', progress: courseProgress });
};