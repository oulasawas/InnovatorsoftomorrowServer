const express = require('express');
const { getAllCourses, createCourse, addLessonToCourse, addSectionToLesson } = require('../controllers/courseController.js');

const router = express.Router();

router.get('/', getAllCourses);
router.post('/', createCourse); // POST /api/courses
// New routes:
router.post('/:courseId/lessons', addLessonToCourse);
router.post('/:courseId/lessons/:lessonId/sections', addSectionToLesson);
module.exports = router
