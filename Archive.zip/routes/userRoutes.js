const express = require('express');
const { enrollCourse, completeSection } = require('../controllers/userController');
const authMiddleware = require('../middleware/authMiddleware');
const router = express.Router();

router.post('/enroll', authMiddleware, enrollCourse);
router.post('/complete', authMiddleware, completeSection);

module.exports = router;